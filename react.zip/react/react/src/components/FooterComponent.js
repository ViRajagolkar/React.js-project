import React, {Component} from 'react';

class FooterComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
            
            </nav>
         );
    }
}
 
export default FooterComponent;